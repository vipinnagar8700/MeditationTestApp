export default{
    WHITE:'#fff',
    BLACK:"#000",
    PRIMARY:'#D9D9D9',
    SECONDARY:"#2EA7DB",
    BUTTON:'#31C059'
}