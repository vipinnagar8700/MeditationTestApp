export default{
    WHITE:'#fff',
    BLACK:"#000",
    PRIMARY:'#8A62E1',
    SECONDARY:"#2DA8ED",
    BUTTON:'#31C059'
}