import { createRef } from 'react';

export const drawerRef = createRef();
